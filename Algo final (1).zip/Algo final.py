import tkinter as tk
from tkinter import messagebox
import ast
import math

class GraphVisualizer:
    def __init__(self, master):
        self.master = master
        self.master.title("Graph Traversal Visualizer")
        self.graph = {}
        self.node_positions = {}
        self.node_radius = 20
        self.create_widgets()
        
    def create_widgets(self):
        self.graph_label = tk.Label(self.master, text="Enter graph (as adjacency list):")
        self.graph_label.pack(pady=(10, 0))
        
        self.graph_entry = tk.Text(self.master, height=10, width=50)
        self.graph_entry.pack(pady=5)
        
        self.start_node_label = tk.Label(self.master, text="Enter starting node:")
        self.start_node_label.pack(pady=(10, 0))
        
        self.start_node_entry = tk.Entry(self.master)
        self.start_node_entry.pack(pady=5)

        self.traversal_method = tk.StringVar(value="DFS")
        self.dfs_radio = tk.Radiobutton(self.master, text="DFS", variable=self.traversal_method, value="DFS")
        self.bfs_radio = tk.Radiobutton(self.master, text="BFS", variable=self.traversal_method, value="BFS")
        self.dijkstra_radio = tk.Radiobutton(self.master, text="Dijkstra", variable=self.traversal_method, value="Dijkstra")
        self.bellmanford_radio = tk.Radiobutton(self.master, text="BellmanFord", variable=self.traversal_method, value="BellmanFord")
        self.dfs_radio.pack(pady=5)
        self.bfs_radio.pack(pady=5)
        self.dijkstra_radio.pack(pady=5)
        self.bellmanford_radio.pack(pady=5)
        
        self.start_button = tk.Button(self.master, text="Start Traversal", command=self.start_traversal)
        self.start_button.pack(pady=10)
        
        self.output_label = tk.Label(self.master, text="Traversal Order:")
        self.output_label.pack(pady=(20, 0))
        
        self.output_text = tk.Text(self.master, height=5, width=50)
        self.output_text.pack(pady=5)
        
        self.canvas = tk.Canvas(self.master, width=600, height=400, bg="white")
        self.canvas.pack(pady=20)
        
    def start_traversal(self):
        graph_input = self.graph_entry.get("1.0", tk.END).strip()
        start_node = self.start_node_entry.get().strip()
        
        try:
            self.graph = ast.literal_eval(graph_input)
            if not isinstance(self.graph, dict):
                raise ValueError("Graph should be a dictionary.")
            if start_node not in self.graph:
                raise ValueError("Starting node not in graph.")
                
            self.output_text.delete("1.0", tk.END)
            self.canvas.delete("all")
            self.node_positions = self.calculate_node_positions()
            self.draw_graph()

            if self.traversal_method.get() == "DFS":
                self.dfs(start_node)
            elif self.traversal_method.get() == "BFS":
                self.bfs(start_node)
            elif self.traversal_method.get() == "Dijkstra":
                self.dijkstra(start_node)
            elif self.traversal_method.get() == "BellmanFord":
                self.bellman_ford(start_node)
        except (ValueError, SyntaxError) as e:
            messagebox.showerror("Error", str(e))
    
    def dfs(self, start_node):
        visited = set()
        stack = [start_node]
        
        while stack:
            node = stack.pop()
            if node not in visited:
                self.output_text.insert(tk.END, f"{node} ")
                visited.add(node)
                self.highlight_node(node)
                self.master.update()
                self.master.after(900)
                for neighbor in self.graph[node]:
                    if neighbor not in visited:
                        stack.append(neighbor)
                        
    def bfs(self, start_node):
        visited = set()
        queue = [start_node]
        
        while queue:
            node = queue.pop(0)
            if node not in visited:
                self.output_text.insert(tk.END, f"{node} ")
                visited.add(node)
                self.highlight_node(node)
                self.master.update()
                self.master.after(900)
                for neighbor in self.graph[node]:
                    if neighbor not in visited:
                        queue.append(neighbor)
                        self.highlight_edge(node, neighbor)
    
    def dijkstra(self, start_node):
        visited = set()
        distance = {node: float('inf') for node in self.graph}
        distance[start_node] = 0
        
        while len(visited) < len(self.graph):
            min_distance = float('inf')
            min_node = None
            
            for node in self.graph:
                if node not in visited and distance[node] < min_distance:
                    min_distance = distance[node]
                    min_node = node
                    
            if min_node is None:
                break
                
            visited.add(min_node)
            for neighbor, weight in self.graph[min_node].items():
                if neighbor not in visited:
                    new_distance = distance[min_node] + weight
                    if new_distance < distance[neighbor]:
                        distance[neighbor] = new_distance
            self.output_text.insert(tk.END, f"{min_node}: {distance[min_node]}\n")
            self.highlight_node(min_node)
            self.master.update()
            self.master.after(900)

    def bellman_ford(self, start_node):
        distance = {node: float('inf') for node in self.graph}
        distance[start_node] = 0
        
        for _ in range(len(self.graph) - 1):
            for node in self.graph:
                for neighbor, weight in self.graph[node].items():
                    if distance[node] + weight < distance[neighbor]:
                        distance[neighbor] = distance[node] + weight
        
        for node in self.graph:
            for neighbor, weight in self.graph[node].items():
                if distance[node] + weight < distance[neighbor]:
                    raise ValueError("Graph contains a negative cycle")
        
        for node, dist in distance.items():
            self.output_text.insert(tk.END, f"{node}: {dist}\n")
            self.highlight_node(node)
            self.master.update()
            self.master.after(900)

    def calculate_node_positions(self):
        positions = {}
        width = self.canvas.winfo_width()
        height = self.canvas.winfo_height()
        node_count = len(self.graph)
        angle_step = 360 / node_count
        center_x = width / 2
        center_y = height / 2
        radius = min(width, height) / 3
        
        for i, node in enumerate(self.graph):
            angle = i * angle_step
            x = center_x + radius * math.cos(math.radians(angle))
            y = center_y + radius * math.sin(math.radians(angle))
            positions[node] = (x, y)
            
        return positions
    
    def draw_graph(self):
        for node, neighbors in self.graph.items():
            x, y = self.node_positions[node]
            self.canvas.create_oval(x - self.node_radius, y - self.node_radius, x + self.node_radius, y + self.node_radius, fill="white", outline="black")
            self.canvas.create_text(x, y, text=node, font=("Arial", 12))
            for neighbor in neighbors:
                nx, ny = self.node_positions[neighbor]
                self.canvas.create_line(x, y, nx, ny, fill="black")
    
    def highlight_node(self, node):
        x, y = self.node_positions[node]
        self.canvas.create_oval(x - self.node_radius, y - self.node_radius, x + self.node_radius, y + self.node_radius, fill="yellow", outline="black")
        self.canvas.create_text(x, y, text=node, font=("Arial", 12))

    def highlight_edge(self, node1, node2):
        x1, y1 = self.node_positions[node1]
        x2, y2 = self.node_positions[node2]
        self.canvas.create_line(x1, y1, x2, y2, fill="red", width=2)

if __name__ == "__main__":
    root = tk.Tk()
    app = GraphVisualizer(root)
    root.mainloop()